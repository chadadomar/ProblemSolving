import matplotlib.pyplot as plt
import numpy as np
    
#la fonction exacte y = exp(-x^2)
def f(x):
    return np.exp(-x*x)  # x peut être vecteur ou nombre réel 

lesx = np.linspace(0,2,40)#lesx est un vecteur de 40 valeurs

#la courbe de la fonction exacte y = exp(-x^2) 
plt.plot(lesx,f(lesx),linewidth=2,label="sol exact") #f(vecteur)---> vecteur 

plt.axis([0,2.05,0,1.02]) 
plt.grid( )
plt.legend()
plt.show()






